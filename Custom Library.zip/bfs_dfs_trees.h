#ifndef GRAPH_TREE_OPERATIONS_H
#define GRAPH_TREE_OPERATIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// --- Graph BFS and DFS ---

// Graph Node Structure
typedef struct Node1 {
    int vertex;
    struct Node1* next;
} Node1;

// Graph Structure
typedef struct Graph {
    int numVertices;
    bool* visited;
    Node1** adjLists;
} Graph;

// Queue for BFS
typedef struct Queue {
    int* items;
    int front, rear, maxSize;
} Queue;

// Utility Functions for Graph
Node1* createNode1(int v) {
    Node1* newNode = (Node1*)malloc(sizeof(Node1));
    newNode->vertex = v;
    newNode->next = NULL;
    return newNode;
}

Graph* createGraph(int vertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->numVertices = vertices;
    graph->visited = (bool*)malloc(vertices * sizeof(bool));
    graph->adjLists = (Node1**)malloc(vertices * sizeof(Node1*));
    int i;
    for (i = 0; i < vertices; i++) {
        graph->adjLists[i] = NULL;
        graph->visited[i] = false;
    }
    return graph;
}

void addEdge(Graph* graph, int src, int dest) {
    Node1* newNode = createNode1(dest);
    newNode->next = graph->adjLists[src];
    graph->adjLists[src] = newNode;

    newNode = createNode1(src);
    newNode->next = graph->adjLists[dest];
    graph->adjLists[dest] = newNode;
}

// Queue Functions for BFS
Queue* createQueue(int size) {
    Queue* queue = (Queue*)malloc(sizeof(Queue));
    queue->items = (int*)malloc(size * sizeof(int));
    queue->front = -1;
    queue->rear = -1;
    queue->maxSize = size;
    return queue;
}

bool isQueueEmpty(Queue* q) {
    return q->front == -1;
}

void enqueue(Queue* q, int value) {
    if (q->rear == q->maxSize - 1) return;
    if (q->front == -1) q->front = 0;
    q->items[++q->rear] = value;
}

int dequeue(Queue* q) {
    if (isQueueEmpty(q)) return -1;
    int item = q->items[q->front];
    if (q->front >= q->rear) {
        q->front = q->rear = -1;
    } else {
        q->front++;
    }
    return item;
}

// BFS Implementation
void bfs(Graph* graph, int startVertex) {
    Queue* queue = createQueue(graph->numVertices);
    graph->visited[startVertex] = true;
    enqueue(queue, startVertex);

    //printf("BFS Traversal: ");
    while (!isQueueEmpty(queue)) {
        int currentVertex = dequeue(queue);
        printf("%d ", currentVertex);

        Node1* temp = graph->adjLists[currentVertex];
        while (temp) {
            int adjVertex = temp->vertex;
            if (!graph->visited[adjVertex]) {
                graph->visited[adjVertex] = true;
                enqueue(queue, adjVertex);
            }
            temp = temp->next;
        }
    }
    printf("\n");
}

// DFS Implementation
void dfs(Graph* graph, int vertex) {
    graph->visited[vertex] = true;
    printf("%d ", vertex);

    Node1* temp = graph->adjLists[vertex];
    while (temp) {
        int adjVertex = temp->vertex;
        if (!graph->visited[adjVertex]) {
            dfs(graph, adjVertex);
        }
        temp = temp->next;
    }
}

// --- Tree Traversals ---

// Binary Tree Node Structure
typedef struct TreeNode {
    int data;
    struct TreeNode *left, *right;
} TreeNode;

// Create a New Tree Node
TreeNode* createTreeNode(int value) {
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->data = value;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Preorder Traversal
void preorder(TreeNode* root) {
    if (root) {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

// Inorder Traversal
void inorder(TreeNode* root) {
    if (root) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

// Postorder Traversal
void postorder(TreeNode* root) {
    if (root) {
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->data);
    }
}

// Display Tree Traversals
void displayTreeTraversals(TreeNode* root) {
    printf("Preorder Traversal: ");
    preorder(root);
    printf("\n");

    printf("Inorder Traversal: ");
    inorder(root);
    printf("\n");

    printf("Postorder Traversal: ");
    postorder(root);
    printf("\n");
}

#endif // GRAPH_TREE_OPERATIONS_H

