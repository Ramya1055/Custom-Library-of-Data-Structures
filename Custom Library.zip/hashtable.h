#ifndef HASHING_H
#define HASHING_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// --- Chain Hashing ---

#define TABLE_SIZE 10

// Hash table structure
typedef struct HashTable {
    int *table;
} HashTable;

// Function to create a new hash table
HashTable* createHashTable() {
    HashTable* ht = (HashTable*)malloc(sizeof(HashTable));
    ht->table = (int*)malloc(sizeof(int) * TABLE_SIZE);
    
    // Initialize all slots to -1 (indicating empty)
    int i;
    for (i = 0; i < TABLE_SIZE; i++) {
        ht->table[i] = -1;
    }

    return ht;
}

// Hash function
int hash(int key) {
    return key % TABLE_SIZE;
}

// Insert function with linear probing
void inserthash(HashTable *ht, int key) {
    int index = hash(key);
    
    // Linear probing
    while (ht->table[index] != -1) {
        index = (index + 1) % TABLE_SIZE;
    }

    ht->table[index] = key;
}

// Search function
bool searchhash(HashTable *ht, int key) {
    int index = hash(key);
    
    // Linear probing search
    while (ht->table[index] != -1) {
        if (ht->table[index] == key) {
            return true;
        }
        index = (index + 1) % TABLE_SIZE;
    }
    return false;
}

// Delete function
void deletehash(HashTable *ht, int key) {
    int index = hash(key);
    
    // Linear probing delete
    while (ht->table[index] != -1) {
        if (ht->table[index] == key) {
            ht->table[index] = -1; // Mark as deleted
            return;
        }
        index = (index + 1) % TABLE_SIZE;
    }

    printf("Key %d not found for deletion.\n", key);
}

// Display function
void displayhash(HashTable *ht) {
    int i;
    for (i = 0; i < TABLE_SIZE; i++) {
        if (ht->table[i] != -1) {
            printf("Index %d: %d\n", i, ht->table[i]);
        }
    }
}

// Node for linked list
typedef struct Node3 {
    int key;
    struct Node3* next;
} Node3;

// Hash table structure
typedef struct HashTable1{
    Node3** table;
} HashTable1;

// Function to create a new hash table
HashTable1* createHashTable1() {
    HashTable1* ht = (HashTable1*)malloc(sizeof(HashTable1));
    ht->table = (Node3**)malloc(sizeof(Node3*) * TABLE_SIZE);
    // Initialize all buckets to NULL
    int i;
    for (i = 0; i < TABLE_SIZE; i++) {
        ht->table[i] = NULL;
    }

    return ht;
}

// Hash function
int hash1(int key) {
    return key % TABLE_SIZE;
}

// Insert function with linked list handling collisions
void inserthasht(HashTable1* ht, int key) {
    int index = hash1(key);
    Node3* newNode = (Node3*)malloc(sizeof(Node3));
    newNode->key = key;
    newNode->next = NULL;

    if (ht->table[index] == NULL) {
        ht->table[index] = newNode;
    } else {
        Node3* current = ht->table[index];
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
    }
}

// Search function
bool searchhasht(HashTable1* ht, int key) {
    int index = hash(key);
    Node3* current = ht->table[index];

    while (current != NULL) {
        if (current->key == key) {
            return true;
        }
        current = current->next;
    }
    return false;
}

// Delete function
void deletehasht(HashTable1* ht, int key) {
    int index = hash(key);
    Node3* current = ht->table[index];
    Node3* prev = NULL;

    while (current != NULL) {
        if (current->key == key) {
            if (prev == NULL) {
                ht->table[index] = current->next; // Remove first node
            } else {
                prev->next = current->next; // Remove non-first node
            }
            free(current);
            return;
        }
        prev = current;
        current = current->next;
    }

    printf("Key %d not found for deletion.\n", key);
}

// Display function
void displayhasht(HashTable1* ht) {
    int i;
    for (i = 0; i < TABLE_SIZE; i++) {
        if (ht->table[i] != NULL) {
            Node3* current = ht->table[i];
            printf("Index %d: ", i);
            while (current != NULL) {
                printf("%d -> ", current->key);
                current = current->next;
            }
            printf("NULL\n");
        }
    }
}

#endif // HASHING_H

