#include<stdio.h>
#include "hashtable.h"
#include "linkedlist.h"
#include "searches_sorts.h"
#include "bfs_dfs_trees.h"
int main() {
    
    printf("\n---HASHING---\n");
HashTable *ht = createHashTable();
    
    printf("Inserting values into the hash table...\n");
    inserthash(ht, 12);
    inserthash(ht, 22);
    inserthash(ht, 32);
    inserthash(ht, 42);
    
    printf("Hash table after insertion:\n");
    displayhash(ht);

    // Searching for values
    int searchKey = 22;
    if (searchhash(ht, searchKey)) {
        printf("Key %d found in the hash table.\n", searchKey);
    } else {
        printf("Key %d not found.\n", searchKey);
    }

    // Deleting a key
    int deleteKey = 22;
    deletehash(ht, deleteKey);
    printf("Hash table after deleting key %d:\n", deleteKey);
    displayhash(ht);

    // Searching again
    if (searchhash(ht, searchKey)) {
        printf("Key %d found in the hash table.\n", searchKey);
    } else {
        printf("Key %d not found.\n", searchKey);
    }

    free(ht->table);
    free(ht);

    HashTable1* ht1 = createHashTable1();
    printf("Inserting values into the hash table...\n");
    inserthasht(ht1, 12);
    inserthasht(ht1, 22);
    inserthasht(ht1, 32);
    inserthasht(ht1, 42);
    
    printf("Hash table after insertion:\n");
    displayhasht(ht1);

    // Searching for values
    int searchKey1 = 22;
    if (searchhasht(ht1, searchKey1)) {
        printf("Key %d found in the hash table.\n", searchKey1);
    } else {
        printf("Key %d not found.\n", searchKey1);
    }

    // Deleting a key
    int deleteKey1 = 22;
    deletehasht(ht1, deleteKey1);
    printf("Hash table after deleting key %d:\n", deleteKey1);
    displayhasht(ht1);

    // Searching again
    if (searchhasht(ht1, searchKey1)) {
        printf("Key %d found in the hash table.\n", searchKey1);
    } else {
        printf("Key %d not found.\n", searchKey1);
    }

    free(ht1->table);
    free(ht1);
    

    printf("\n---LINKED LIST---\n");
    Node* head = NULL; // Initialize the head of the linked list

    // Insert at the beginning
    insertAtBeginning(&head, 10);
    insertAtBeginning(&head, 20);
    insertAtBeginning(&head, 30);

    // Insert at the end
    insertAtEnd(&head, 40);
    insertAtEnd(&head, 50);

    // Display the list
    printf("\n\nLinked List after insertions:\n");
    displayList(head);

    // Insert after a specific node
    if (insertAfter(head, 20, 25)) {
        printf("Inserted 25 after 20.\n");
    } else {
        printf("Node 20 not found.\n");
    }

    // Display the list
    printf("Linked List after insertion after a specific node:\n");
    displayList(head);

    // Search for a value
    int key = 25;
    if (searchlist(head, key)) {
        printf("Found %d in the list.\n", key);
    } else {
        printf("%d not found in the list.\n", key);
    }

    // Delete a node
    if (deleteNode(&head, 30)) {
        printf("Deleted node with value 30.\n");
    } else {
        printf("Node with value 30 not found.\n");
    }

    // Display the list
    printf("Linked List after deletion:\n");
    displayList(head);

    // Free the entire list
    freeList(&head);
    printf("Linked List after freeing all nodes:\n");
    displayList(head);
    
    printf("\n---SORTS AND SEARCHES---\n");

    int arr[] = {64, 34, 25, 12, 22, 11, 90};
    int size = sizeof(arr) / sizeof(arr[0]);
    int target;

    printf("\n\nOriginal Array:\n");
    printArray(arr, size);

    // Merge Sort
    printf("\nPerforming Merge Sort:\n");
    mergeSort(arr, 0, size - 1);
    printArray(arr, size);

    // Quick Sort
    int arr2[] = {64, 34, 25, 12, 22, 11, 90};
    printf("\nPerforming Quick Sort:\n");
    quickSort(arr2, 0, size - 1);
    printArray(arr2, size);

    // Linear Search
    printf("\nPerforming Linear Search (Target: 25):\n");
    target = 25;
    int linIndex = linearSearch(arr, size, target);
    if (linIndex != -1) {
        printf("Element %d found at index %d (Linear Search).\n", target, linIndex);
    } else {
        printf("Element %d not found (Linear Search).\n", target);
    }

    // Binary Search
    printf("\nPerforming Binary Search (Target: 25):\n");
    target = 25;
    int binIndex = binarySearch(arr, 0, size - 1, target);
    if (binIndex != -1) {
        printf("Element %d found at index %d (Binary Search).\n", target, binIndex);
    } else {
        printf("Element %d not found (Binary Search).\n", target);
    }
    printf("\n---TREES AND GRAPHS---\n");
    // --- Tree Operations ---
   TreeNode* root = createTreeNode(1);
    root->left = createTreeNode(2);
    root->right = createTreeNode(3);
    root->left->left = createTreeNode(4);
    root->left->right = createTreeNode(5);

    printf("\n\nTree Traversals:\n\n");
    displayTreeTraversals(root);

    // --- Graph Operations ---
    
    Graph* graph = createGraph(5);
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 4);
    addEdge(graph, 1, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 3);
    addEdge(graph, 3, 4);

    printf("\nGraph Traversals:\n\n");
    
    printf("BFS traversal from Vertex 0:\n");
    bfs(graph, 0);
int i;
    for (i = 0; i < graph->numVertices; i++) graph->visited[i] = false;
    printf("DFS traversal from Vertex 0:\n");
    dfs(graph, 0);
    printf("\n");

    return 0;
}
